//Image Gallery

'use strict'

// Ready results in focus on "upper kings" with the associated image and title and loads evt handlers
$(document).ready(() => {
    // Preload images
    $("#image_list a").each(function() {
        const img = new Image();
        img.src = $(this).attr("href");
    });

    // Select the first link in the image list
    const $firstLink = $("#image_list a").first();
    
    // Set focus on the first link
    $firstLink.focus();
    
    // Set caption to fist link's title
    $("#caption").text($firstLink.attr("title"));
    
    // Set gallery image to first link's image
    $("#image").attr("src", $firstLink.attr("href"));

    // Set event handlers for image links
    $("#image_list a").click( evt => {

        // Prevent default action
        evt.preventDefault();
        
        //Get current target
        const link = evt.currentTarget;

        // Set gallery image to selected target
        $("#image").attr("src", $(link).attr("href"));

        // Set gallery caption to selected target
        $("#caption").text(link.title);

        // Reset focus on the first link
        $firstLink.focus();

    })
});

